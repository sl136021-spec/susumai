# 俗俗賣五金百貨網站

## 上傳 GitHub
請把這個資料夾「解壓縮後裡面的內容」全部上傳，不要只上傳 ZIP。

必須看到：
- index.html
- products.html
- style.css
- script.js
- admin/
- data/
- assets/

## 後台
後台網址：/admin

真正可儲存後台需要 Netlify：
- Import from GitHub
- 開啟 Identity
- 開啟 Git Gateway
